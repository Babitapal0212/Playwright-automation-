import { Page, Locator } from '@playwright/test';

export class DashboardPage {
  readonly page: Page;
  readonly dashboardHeading: Locator;
  readonly pimLink: Locator;
  readonly directoryLink: Locator;
  readonly timeAtWork: Locator;

  constructor(page: Page) {
    this.page = page;
    this.dashboardHeading = page.getByRole('heading', { name: 'Dashboard' });
    this.pimLink = page.getByRole('link', { name: 'PIM' });
    this.directoryLink = page.getByRole('link', { name: 'Directory' });
    this.timeAtWork = page.getByText('Time at Work');
  }

  async openPIM() {
    await this.pimLink.click();
  }

  async openDirectory() {
    await this.directoryLink.click();
  }
}