
import { Page, Locator } from '@playwright/test';

export class LoginPage {
  readonly page: Page;
  readonly username: Locator;
  readonly password: Locator;
  readonly loginButton: Locator;
  readonly requiredMessage: Locator;
  readonly invalidCredentials: Locator;

  constructor(page: Page) {
    this.page = page;
    this.username = page.locator('input[name="username"]');
    this.password = page.locator('input[name="password"]');
    this.loginButton = page.locator('button[type="submit"]');
    this.requiredMessage = page.getByText('Required');
    this.invalidCredentials = page.getByText('Invalid credentials');
  }

  async open() {
    await this.page.goto('https://opensource-demo.orangehrmlive.com/');
  }

  async login(username: string, password: string) {
    await this.username.fill(username);
    await this.password.fill(password);
    await this.loginButton.click();
  }

  async loginWithValidCredentials() {
    await this.login('Admin', 'admin123');
  }

  async logout() {
    await this.page.locator('.oxd-userdropdown-name').click();
    await this.page.getByRole('menuitem', { name: 'Logout' }).click();
  }
}
