import { test, expect } from '@playwright/test';
import { LoginPage } from '../pages/LoginPage';
import { DashboardPage } from '../pages/DashboardPage';
import { DirectoryPage } from '../pages/DirectoryPage';

test.describe('OrangeHRM Automation Tests', () => {
  let loginPage: LoginPage;
  let dashboardPage: DashboardPage;
  let directoryPage: DirectoryPage;

  test.beforeEach(async ({ page }) => {
    loginPage = new LoginPage(page);
    dashboardPage = new DashboardPage(page);
    directoryPage = new DirectoryPage(page);

    await loginPage.open();
  });

  test('TC01 - Verify successful login', async ({ page }) => {
    await loginPage.loginWithValidCredentials();

    await expect(page).toHaveURL(/dashboard/);
    await expect(dashboardPage.dashboardHeading).toBeVisible();
  });

  test('TC02 - Verify invalid login', async () => {
    await loginPage.login('WrongUser', 'WrongPassword');

    await expect(loginPage.invalidCredentials).toBeVisible();
  });

  test('TC03 - Verify username required validation', async () => {
    await loginPage.password.fill('admin123');
    await loginPage.loginButton.click();

    await expect(loginPage.requiredMessage.first()).toBeVisible();
  });

  test('TC04 - Verify password required validation', async () => {
    await loginPage.username.fill('Admin');
    await loginPage.loginButton.click();

    await expect(loginPage.requiredMessage.first()).toBeVisible();
  });

  test('TC05 - Verify Dashboard after login', async ({ page }) => {
    await loginPage.loginWithValidCredentials();

    await expect(page).toHaveURL(/dashboard/);
    await expect(dashboardPage.dashboardHeading).toBeVisible();
    await expect(dashboardPage.timeAtWork).toBeVisible();
  });

  test('TC06 - Verify PIM navigation', async ({ page }) => {
    await loginPage.loginWithValidCredentials();
    await dashboardPage.openPIM();

    await expect(page).toHaveURL(/pim/);
    await expect(page.getByRole('heading', { name: 'PIM' })).toBeVisible();
  });

  test('TC07 - Verify Directory navigation', async ({ page }) => {
    await loginPage.loginWithValidCredentials();
    await dashboardPage.openDirectory();

    await expect(page).toHaveURL(/directory/);
    await expect(directoryPage.directoryHeading).toBeVisible();
  });

  test('TC08 - Verify logout functionality', async ({ page }) => {
    await loginPage.loginWithValidCredentials();
    await loginPage.logout();

    await expect(loginPage.username).toBeVisible();
    await expect(loginPage.loginButton).toBeVisible();
  });
});