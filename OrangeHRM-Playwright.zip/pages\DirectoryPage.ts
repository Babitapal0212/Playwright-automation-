
import { Page, Locator } from '@playwright/test';

export class DirectoryPage {
  readonly page: Page;
  readonly directoryHeading: Locator;

  constructor(page: Page) {
    this.page = page;
    this.directoryHeading = page.locator('h5.oxd-table-filter-title');
  }
}
