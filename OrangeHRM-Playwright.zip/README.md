
# OrangeHRM Playwright Automation

## Project Overview
This project contains 8 automated test cases for the OrangeHRM Demo application using Playwright, TypeScript and Page Object Model (POM).

## Application URL
https://opensource-demo.orangehrmlive.com/

## Technology
- Playwright
- TypeScript
- Page Object Model (POM)
- Chromium

## Installation
Install project dependencies:

```bash
npm install
```

## Execution
Run all automated test cases using a single command:

```bash
npm test
```

## Test Scenarios

| Test ID | Test Scenario |
|---|---|
| TC01 | Verify successful login |
| TC02 | Verify invalid login |
| TC03 | Verify username required validation |
| TC04 | Verify password required validation |
| TC05 | Verify Dashboard after login |
| TC06 | Verify PIM navigation |
| TC07 | Verify Directory navigation |
| TC08 | Verify logout functionality |

## Project Structure

- pages/LoginPage.ts - Login locators and actions
- pages/DashboardPage.ts - Dashboard locators and navigation
- pages/DirectoryPage.ts - Directory page locators
- tests/orangehrm.spec.ts - Automated test scenarios
- playwright.config.ts - Playwright configuration

## Run Tests

```bash
npm test
```
